//Zahra-Moghadam-Final-Project
import java.util.Scanner;
public class Main 
{
	
	public static void main(String[] args) 
	{
		int t=1;
		
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		while (t>0) {
			System.out.println("_______________________________________\n");
			
			System.out.println("    >>> Please Choose an Option <<<    ");
			
			System.out.println("\n 1: Reverse on Main and Sub Diameter" + "\n\n 2: Exit!");
				
			System.out.println("_______________________________________");
			t = input.nextInt();
			if (t == 1) {
				int n;
				System.out.println("Please Enter Order of the Matrix:");
			    n = input.nextInt();
				n = Math.abs(n);
				System.out.println("Enter the Maximum Range of Elements:");
				int digit = input.nextInt();
				digit = Math.abs(digit);
				
				MatrixZ H=new MatrixZ(n,digit);
				
				System.out.println("The Randomized Matrix is: ");
				H.show("A");
				System.out.println("The Reversed matrix on Main Diameter is: ");
				H.ReverseOnMainDiameter(H,digit).show("B");
				System.out.println("The Reversed Matrix on Sub Diameter is: ");
				H.ReverseOnMainDiameter(H, digit).ReverseOnSubDiameter(H, digit).show("Z");
				
			}//End of if
			else
				t = 0;
		}//End of while

	}//End of Main
	//Zahra-Moghadam-Final-Project
}//End of Class Main
