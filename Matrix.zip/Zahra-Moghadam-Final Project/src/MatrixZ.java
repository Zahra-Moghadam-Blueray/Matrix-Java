//Zahra-Moghadam-Final-Project
import java.util.Random;

public class MatrixZ
{
	public int n;
	public Node start;
	
	public MatrixZ(int order, int digit)
	{
		n = order;
		start = new Node();
		Random rand = new Random();
		start.data = rand.nextInt()%digit;

		Node p = start;//p--> start
		for(int i = 0; i < order; i++)
		{
			Node t = null;//t-->up
			if(i > 0)
			{
				t = p;
				Node r = new Node();//r--next
				r.data = rand.nextInt()%digit;
				
				p.down = r;
				r.up = p;
				p = r;
			}//
			
			Node q = p; //q-->prev
			for(int j = 1; j < order; j++) 
			{
				Node w = new Node();//w-->next
				w.data = rand.nextInt()%digit;

				q.next = w;
				w.prev = q;
				if (t != null) 
				{
					t = t.next;
					if(t !=null) 
					{
						w.up = t;
						t.down = w;
					}
				}
				q = w;
			}
		}
	}//End Matrix

	public int Length()
	{
		int max = 0;
		Node s = start;
		Node q = s;//q-->prev
		for (int i = 0; i < n; i++) 
		{
			q = s;
			for (int j = 0; j < n; j++) 
			{
				int u = Math.abs(q.data);
				if (u > max)
					max = u;
				q = q.next;
			}
			q = s.down;
			s = q;
		}
		
		int count = 1;
		while (max > 0)
		{
			count++;
			max /= 1000;
		}
		return count;
	}//End of Length

	public String SetField(int data, int c)
	{
		String string = "";
		String s = data + "";  //*****
		int a = c - s.length();
		for (int i = 0; i < a; i++)
			string = string + " ";
		string = string + s;
		return string;
	}//End of SetField
	
    public void show(String name)
    {
    	System.out.println("Matrix " + name + " --> " + n + "*" + n);
    	int c = Length();
    	Node s = start;
		Node q= s;
		for (int i = 0; i < n; i++) 
		{
			for (int r = 0; r < n * (c + 4) + 2; r++)
				System.out.print("-");
			q = s;
			
			System.out.print("\n|");
            for (int j = 0; j < n; j++) {
                System.out.print(" " + SetField(q.data, c) + " |");
                q = q.next;
            }
            q = s.down;
            s = q;
            System.out.println();
        }
        for (int z = 0; z < n * (c + 4) + 2; z++)//***
            System.out.print("-");
        System.out.println();
	}//End of Show
	

	public Node getNode(int row, int col) 
	{
		Node node = start;
        for (int i = 0; i <row ; i++) 
        {
            node=node.down;
        }
        for (int i = 0; i <col ; i++)
        {
            node=node.next;
        }
		return node;
	}//End of getNode
	
///////Reverse\\\\\\\\\\	
	public MatrixZ ReverseOnMainDiameter(MatrixZ A, int digit)
	{
		MatrixZ Z = new MatrixZ (n,digit);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if(i == j)
                    Z.getNode(i, j).data = A.getNode(i, j).data;
                else
                	Z.getNode(i, j).data = getNode(j, i).data;
		return Z;
	}//End of Class Main Diameter

	public MatrixZ ReverseOnSubDiameter(MatrixZ B, int digit)
	{
		MatrixZ Z = new MatrixZ (n,digit);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				Z.getNode(i, j).data = getNode(n - j - 1, n - i - 1).data;
		return Z;
	}//End of Reverse on Main Diameter


}//End of Class MatrixZ

//Zahra-Moghadam-Final-Project