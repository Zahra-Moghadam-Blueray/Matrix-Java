//Zahra-Moghadam-Final-Project
class Node
{
	
	public int data;//value of each node
	
	public Node next;//Node next created
	public Node prev;//Node prev created
	public Node up;//Node up created
	public Node down;//Node down created


	
	
	public Node()
{
		
		next=prev=up=down=null;//at first
		
		data=0;
}//End of Node
	
	
}//End of Class Node
//Zahra-Moghadam-Final-Project